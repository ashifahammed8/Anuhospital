
    <!--Start page-banner-->
    <section class="page-banner" style="background-image:url(images/resources/banner.jpg);">
        <div class="container">
    		<div class="content">
                <h2>Service Details</h2>
            </div>
            <ul class="breadcumb">
                <li><a href="index.php">Home</a><i class="fa fa-chevron-right" aria-hidden="true"></i></li>
                <li><a  class="active" href="service-single.php">Service Details</a></li>
            </ul>
        </div>
    </section>
    <!--End page-banner-->