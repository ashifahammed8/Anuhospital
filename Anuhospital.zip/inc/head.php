	<title> Anu Hospitals </title> 

	<!-- All the link file here -->
	<meta charset="UTF-8">
	<meta name="description" content="" />
	<meta name="keywords" content="" />
	<!-- mobile responsive meta -->
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<link rel="stylesheet" href="css/style.css">
	<link rel="stylesheet" href="css/responsive.css">
	<link rel="stylesheet" href="fonts/flaticon.css" /> 
	<link rel="stylesheet" href="font/flaticon.css">
	<link rel="stylesheet" href="font2/flaticon.css">
	<link rel="stylesheet" href="font5/flaticon.css">
	<link rel="stylesheet" href="font10/flaticon.css">

	
	
	<!--favicon-->
	<link rel="apple-touch-icon" sizes="180x180" href="images/favicon/apple-touch-icon.png">
	<link rel="icon" type="image/png" href="images/favicon/favicon-32x32.png" sizes="32x32">
	<link rel="icon" type="image/png" href="images/favicon/favicon-16x16.png" sizes="16x16">
	
	<link href="profile/css/style.css" rel="stylesheet">
	<link href="profile/css/responsive.css" rel="stylesheet">

	<!-- Animation, Icon Fonts, Bootsrap styles -->
	<link rel='stylesheet' href='assets2/stylesheets/vendor/aos.min.css' type='text/css' media='all' />
	