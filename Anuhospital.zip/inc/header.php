 <!-- Header section -->
	
	<!-- Top Header -->
	<div class="boxed_wrapper">
	  <div class="header-top">
		<div class="container clearfix">
			<!--Top Left-->
			<div class="top-left pull-left">
			<ul class="links-nav clearfix">
				<li><a href="#"><span class="fa fa-phone"></span> Call:0866-2438881/2438889 </a></li>
				<li><a href="#"><span class="fa fa-envelope"></span>Email: anuhospitals@yahoo.com</a></li>
			</ul>
		</div>
	<!-- End Top Header -->		


		<!-- Header Top Right-->
         <div class="top-right pull-right">
		   <div class="social-links clearfix">
			 <a href="#"><span class="fa fa-facebook-f"></span></a>
				<a href="#"><span class="fa fa-twitter"></span></a>
				<a href="#"><span class="fa fa-linkedin"></span></a>
				<a href="#"><span class="fa fa-instagram"></span></a>
				<a href="#"><span class="fa fa-pinterest-p"></span></a>
			</div>
		 </div>
	   </div>
	</div>
	 <!-- Header Top End -->


	  <!-- Navigation Menu -->
	  <section class="mainmenu-area stricky">
		 <div class="container">
		  <div class="row">
		    <div class="col-md-4">
			 <div class="main-logo">
				<a href="index.php"><img src="images/logo/LOHO.png" alt="name"></a>
			</div>
		</div>
					
			<div class="col-md-8 menu-column">
			  <nav class="main-menu">
			    <div class="navbar-header">     
				  <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
				    <span class="icon-bar"></span>
				    <span class="icon-bar"></span>
				    <span class="icon-bar"></span>
				    <span class="icon-bar"></span>
				   </button>
				</div>
			    
			    <div class="navbar-collapse collapse clearfix">
				   <ul class="navigation clearfix">
						<li class="<?php echo $page_id == 1 ? 'current' : ''?> "> <a href="index.php"> HOME </a></li>
						<li class="<?php echo $page_id == 2 ? 'current' : ''?> "><a href="about.php"> ABOUT </a></li>
						<li class="<?php echo $page_id == 3 ? 'current' : ''?> "><a href="service.php"> SERVICE </a></li>
						<li class="<?php echo $page_id == 7 ? 'current' : ''?> "><a href="packages.php"> Health Packages </a></li>
						<li class="<?php echo $page_id == 4 ? 'current' : ''?> "><a href="gallery.php"> Gallery </a></li>
						<li class="<?php echo $page_id == 08 ? 'current' : ''?> "><a href="team.php"> Team </a></li>
						<li class="<?php echo $page_id == 5 ? 'current' : ''?> "><a href="bloggrid.php"> BLOG </a></li>
						<li class="<?php echo $page_id == 6 ? 'current' : ''?> "><a href="contact.php"> CONTACT </a></li>
				   </ul>

				    
				    <ul class="mobile-menu clearfix">
				        <li class="<?php echo $page_id == 1 ? 'current' : ''?> "><a href="index.php"> HOME </a></li>                 
				        <li class="<?php echo $page_id == 2 ? 'current' : ''?> "><a href="about.php"> ABOUT </a></li>
						<li class="<?php echo $page_id == 3 ? 'current' : ''?> "><a href="service.php"> SERVICE </a></li>
						<li class="<?php echo $page_id == 7 ? 'current' : ''?> "><a href="packages.php"> Health Packages </a></li>
						<li class="<?php echo $page_id == 4 ? 'current' : ''?> "><a href="gallery.php"> Gallery </a></li>
						<li class="<?php echo $page_id == 08 ? 'current' : ''?> "><a href="team.php"> Team </a></li>
						<li class="<?php echo $page_id == 5 ? 'current' : ''?> ">><a href="bloggrid.php"> BLOG </a></li>
						<li class="<?php echo $page_id == 6 ? 'current' : ''?> ">><a href="contact.php">CONTACT</a></li>
					 </ul>
		            </div>
		        </nav>
			</div>
					<div class="col-md-2">
						
					</div>
	    	</div>
	    </div>
	</section>
		<!-- End of the Navigation Menu -->