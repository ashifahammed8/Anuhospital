<!--subscribe-us section-->
		<section class="subscribe-us" style="background-image:url(images/background/bg-3.jpg);">
			<div class="container">
				<div class="row">
					<div class="overlay">
						<div class="col-md-12">
							<h3 style="text-align: center;" data-aos="zoom-in">OUR MISSION</h3>
							<p style="font-weight: bold; font-size: 20px; text-align: center;" data-aos="zoom-out">To provide the finest standards in Holistic Health care
							and medicare for a wide section of socity , showing respect for our 
						patients in whatever we do</p>
						</div>
						
					</div>	
					
				</div>
			</div>
		</section>
		<!-- Subscribe us End -->